
const langToggle = document.getElementById("lang-toggle");

const texts={
article1:{
bg:{title:"Личен блог на Нежи",articleTitle:"Как започнах моя блог",p1:"Това е първата ми статия. В нея ще споделя защо реших да започна блог.",p2:"Блогът е начин да споделям мислите си.",footer:"© 2025 Личен блог на Нежи",button:"EN"},
en:{title:"Neji's Personal Blog",articleTitle:"How I Started My Blog",p1:"This is my first article. In it I share why I started a blog.",p2:"The blog is a way to share my thoughts.",footer:"© 2025 Neji's Personal Blog",button:"BG"}
},
article2:{
bg:{title:"Личен блог на Нежи",articleTitle:"Любими книги и цитати",p1:"Обичам да чета и любимите ми цитати ме вдъхновяват.",p2:"Четенето ми дава нови идеи.",footer:"© 2025 Личен блог на Нежи",button:"EN"},
en:{title:"Neji's Personal Blog",articleTitle:"Favorite Books and Quotes",p1:"I love reading and my favorite quotes inspire me.",p2:"Reading gives me new ideas.",footer:"© 2025 Neji's Personal Blog",button:"BG"}
},
article3:{
bg:{title:"Личен блог на Нежи",articleTitle:"Моето вдъхновение",p1:"Вдъхновението ми идва от малки неща.",p2:"Пиша, за да споделям истории.",footer:"© 2025 Личен блог на Нежи",button:"EN"},
en:{title:"Neji's Personal Blog",articleTitle:"My Inspiration",p1:"My inspiration comes from small things.",p2:"I write to share stories.",footer:"© 2025 Neji's Personal Blog",button:"BG"}
}
};

const path=window.location.pathname;
let currentArticle="article1";
if(path.includes("article2")) currentArticle="article2";
if(path.includes("article3")) currentArticle="article3";
let currentLang="bg";
langToggle.addEventListener("click",()=>{
currentLang=currentLang==="bg"?"en":"bg";
const lang=texts[currentArticle][currentLang];
document.getElementById("title").textContent=lang.title;
document.getElementById("article-title").textContent=lang.articleTitle;
document.getElementById("p1").textContent=lang.p1;
document.getElementById("p2").textContent=lang.p2;
document.getElementById("footer-text").textContent=lang.footer;
langToggle.textContent=lang.button;
});
